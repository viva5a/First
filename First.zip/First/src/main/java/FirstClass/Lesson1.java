package FirstClass;

public class Lesson1 {
    public static void main(String[] args) {
        System.out.println("HelloWorld");

        //printThreeWords();

        // checkSumSign();

        //printColor();

        compareNumbers();

    }


    private static void printThreeWords() {
        System.out.println("_Orange");
        System.out.println("_Banana");
        System.out.println("_Apple");
    }

    private static void checkSumSign() {
        int varA = 5;
        int varB = 7;
        int varC = varA + varB;
        System.out.println("varC = " + varC);

        if (varC >= 0) {
            System.out.println("Сумма положительная");
        }
        if (varC < 0) {
            System.out.println("Сумма отрицательная");
        }
    }

    private static void printColor() {
        int A1 = 55;

        if (A1 < 100) {
            System.out.println("Красный");
        }
        if (A1 == 100) {
            System.out.println("Желтый");
        }
        if (A1 > 100) {
            System.out.println("Зеленый");
        }
    }

    private static void compareNumbers() {
    int a = 10;
        if (a > 3) {
            System.out.println("А больше трёх");
        } else {
            System.out.println("А меньше трёх");
        }
    }
}






