package FirstClass;

public class TwoClass {
}
